const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.canView = async function(req, res, next) {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    if (user.usertype === 'Admin' || user.usertype === 'Manager' || (user.usertype === 'User' && req.params.userId === user.id)) {
        next();
    } else {
        res.status(403).send('Access denied');
    }
}

exports.canEdit = async function(req, res, next) {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    if (user.usertype === 'Admin' || user.usertype === 'Manager' || (user.usertype === 'User' && req.params.userId === user.id)) {
        next();
    } else {
        res.status(403).send('Access denied');
    }
}

exports.canDelete = async function(req, res, next) {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    if (user.usertype === 'Admin') {
        next();
    } else {
        res.status(403).send('Access denied');
    }
}
